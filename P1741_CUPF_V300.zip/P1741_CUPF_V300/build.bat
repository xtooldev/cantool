@echo off
cl /nologo /EHsc /utf-8 SecurityCheck_MD1CS089_P1741.cpp /Fe:SecurityCheck_MD1CS089_P1741.exe
cl /nologo /EHsc /utf-8 SeedKey_MD1CS089_P1741.cpp sha1_b3.cpp /Fe:SeedKey_MD1CS089_P1741.exe
