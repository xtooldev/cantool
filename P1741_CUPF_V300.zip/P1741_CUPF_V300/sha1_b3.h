
namespace nsp_zznissan_sha1_b3
{

	typedef struct {
		unsigned long state[5];
		unsigned long count[2];
		unsigned char buffer[64];
	} SHA1B3_CTX;

	//#define LITTLE_ENDIAN

#define rol(value, bits) (((value) << (bits)) | ((value) >> (32 - (bits))))

/* blk0() and blk() perform the initial expand. */
/* I got the idea of expanding during the round function from SSLeay */
#ifdef LITTLE_ENDIAN
#	define blk0(i) (block->l[i] = (rol(block->l[i],24)&0xFF00FF00) \
    |(rol(block->l[i],8)&0x00FF00FF))
#else
#	define blk0(i) block->l[i]
#endif

#define blk(i) (block->l[i&15] = rol(block->l[(i+13)&15]^block->l[(i+8)&15] \
    ^block->l[(i+2)&15]^block->l[i&15],1))


#define T0(v,w,x,y,z,i,j) t=rol((w^x^y)+blk0(i)+v, j); x=rol(x,10); v=z+t;

#define TR0(v,w,x,y,z,i,j) t=rol((x&w|y&~w)+blk0(i)+v+0x5A827999, j); x=rol(x,10); v=z+t;
#define TR1(v,w,x,y,z,i,j) t=rol(((w|~x)^y)+blk0(i)+v+0x6ED9EBA1, j); x=rol(x,10); v=z+t;
#define TR2(v,w,x,y,z,i,j) t=rol((~y&x|y&w)+blk0(i)+v+0x8F1BBCDC, j); x=rol(x,10); v=z+t;
#define TR3(v,w,x,y,z,i,j) t=rol(((~y|x)^w)+blk0(i)+v+0xA953FD4E, j); x=rol(x,10); v=z+t;

#define TR4(v,w,x,y,z,i,j) t=rol(((~y|x)^w)+blk0(i)+v+0x50A28BE6, j); x=rol(x,10); v=z+t;
#define TR5(v,w,x,y,z,i,j) t=rol((y&w|~y&x)+blk0(i)+v+0x5C4DD124, j); x=rol(x,10); v=z+t;
#define TR6(v,w,x,y,z,i,j) t=rol(((w|~x)^y)+blk0(i)+v+0x6D703EF3, j); x=rol(x,10); v=z+t;
#define TR7(v,w,x,y,z,i,j) t=rol((y&~w|x&w)+blk0(i)+v+0x7A6D76E9, j); x=rol(x,10); v=z+t;


	void SHA1B3_Transform(unsigned long state[5], unsigned char buffer[64]);
	void SHA1B3_Init(SHA1B3_CTX* context);
	void SHA1B3_Update(SHA1B3_CTX* context, unsigned char* data, unsigned int len);
	void SHA1B3_Final(unsigned char digest[20], SHA1B3_CTX* context);
	template<class T>
	T __ROL__(T value, unsigned int count)
	{
		unsigned int nbits = sizeof(T) * 8;
		count %= nbits;

		T high = value >> (nbits - count);
		value <<= count;
		value |= high;
		return value;
	}
	template<class T>
	T __ROR__(T value, unsigned int count)
	{
		const unsigned int nbits = sizeof(T) * 8;
		count %= nbits;

		T low = value << (nbits - count);
		value >>= count;
		value |= low;
		return value;
	}
}
