// SeedKey_MD1CS089_P1741.cpp
//
// Tests the MD1CS089 seed/key algorithms that exist in the two inspected
// projects against the 8 seed/key pairs captured in 安全算法.txt:
//
//   HD_FSWHOLEAREA  -> HD_WHOLEAREAFS module (MD1CS089_APP.cpp)
//       CalcMaskKey   : SafeAccess_MD1CS089(), 27 01/27 02, 32-entry XOR mask
//       CalcSha256Key : SafeAccess_Type2(),    27 01/27 02, SHA-256 based
//   HD_ZZNISSAN     -> CRUIQI_ZD25T6_ENG (RUIQI_ZD25T6_ENG.cpp)
//       Alg162        : SafeAccess(),          27 0B/27 0C, SHA1B3(mask16||seed)
//
// Build (MSVC): cl /nologo /EHsc /utf-8 SeedKey_MD1CS089_P1741.cpp sha1_b3.cpp

#include <stdio.h>
#include <string.h>
#include "sha1_b3.h"

static const unsigned int g_maskTable[32] =
{
	0x0BDDFA78U,0x17BBF4F0U,0x2F77E9E0U,0x5EEFD3C0U,
	0xBDDFA780U,0xF9FB2D56U,0x71B238FAU,0xE36471F4U,
	0x448C81BEU,0x8919037CU,0x907664AEU,0xA2A8AB0AU,
	0xC7153442U,0x0C6E0AD2U,0x18DC15A4U,0x31B82B48U,
	0x63705690U,0xC6E0AD20U,0x0F853816U,0x1F0A702CU,
	0x3E14E058U,0x7C29C0B0U,0xF8538160U,0x72E36096U,
	0xE5C6C12CU,0x49C9E00EU,0x9393C01CU,0xA563E26EU,
	0xC883A68AU,0x13432F42U,0x26865E84U,0x4D0CBD08U
};

/* HD_FSWHOLEAREA: HD_WHOLEAREAFS/MD1CS089_APP.cpp, SafeAccess_MD1CS089() */
static unsigned int CalcMaskKey(unsigned int seed)
{
	unsigned int key = 0;
	int i;
	for (i = 0; i < 32; ++i)
	{
		if (seed & (1U << i))
			key ^= g_maskTable[i];
	}
	return key;
}

/* HD_ZZNISSAN: RUIQI_ZD25T6_ENG.cpp, Alg162() */
static unsigned int Alg162(unsigned char* seed)
{
	unsigned char mask[16] =
	{
		0x9C,0xD1,0xAE,0x64,0x12,0xD9,0x98,0x33,
		0xE7,0x87,0xF2,0x12,0xFD,0xCC,0x29,0xD7
	};
	unsigned char digest[20] = { 0 };
	unsigned char pin[8] = { 0 };
	nsp_zznissan_sha1_b3::SHA1B3_CTX ctx;

	memcpy(pin, seed, 4);
	nsp_zznissan_sha1_b3::SHA1B3_Init(&ctx);
	nsp_zznissan_sha1_b3::SHA1B3_Update(&ctx, mask, 16);
	nsp_zznissan_sha1_b3::SHA1B3_Update(&ctx, pin, 4);
	nsp_zznissan_sha1_b3::SHA1B3_Final(digest, &ctx);
	return ((unsigned int)digest[0] << 24) | ((unsigned int)digest[1] << 16) |
		((unsigned int)digest[2] << 8) | digest[3];
}

/* Minimal SHA-256 for the SafeAccess_Type2 algorithm. */
typedef struct { unsigned int h[8]; unsigned char buf[64]; unsigned int used; unsigned long long total; } SHA256_CTX;
static const unsigned int g_k[64] = {
	0x428A2F98U,0x71374491U,0xB5C0FBCFU,0xE9B5DBA5U,0x3956C25BU,0x59F111F1U,0x923F82A4U,0xAB1C5ED5U,
	0xD807AA98U,0x12835B01U,0x243185BEU,0x550C7DC3U,0x72BE5D74U,0x80DEB1FEU,0x9BDC06A7U,0xC19BF174U,
	0xE49B69C1U,0xEFBE4786U,0x0FC19DC6U,0x240CA1CCU,0x2DE92C6FU,0x4A7484AAU,0x5CB0A9DCU,0x76F988DAU,
	0x983E5152U,0xA831C66DU,0xB00327C8U,0xBF597FC7U,0xC6E00BF3U,0xD5A79147U,0x06CA6351U,0x14292967U,
	0x27B70A85U,0x2E1B2138U,0x4D2C6DFCU,0x53380D13U,0x650A7354U,0x766A0ABBU,0x81C2C92EU,0x92722C85U,
	0xA2BFE8A1U,0xA81A664BU,0xC24B8B70U,0xC76C51A3U,0xD192E819U,0xD6990624U,0xF40E3585U,0x106AA070U,
	0x19A4C116U,0x1E376C08U,0x2748774CU,0x34B0BCB5U,0x391C0CB3U,0x4ED8AA4AU,0x5B9CCA4FU,0x682E6FF3U,
	0x748F82EEU,0x78A5636FU,0x84C87814U,0x8CC70208U,0x90BEFFFAU,0xA4506CEBU,0xBEF9A3F7U,0xC67178F2U };
#define ROTR32(x,n) (((x)>>(n))|((x)<<(32-(n))))
static void Sha256Block(SHA256_CTX* c, const unsigned char* p)
{
	unsigned int w[64], a, b, d, e, f, g, h, t1, t2, cc;
	int i;
	for (i = 0; i < 16; ++i)
		w[i] = ((unsigned int)p[i*4]<<24)|((unsigned int)p[i*4+1]<<16)|((unsigned int)p[i*4+2]<<8)|p[i*4+3];
	for (i = 16; i < 64; ++i)
		w[i] = (ROTR32(w[i-2],17)^ROTR32(w[i-2],19)^(w[i-2]>>10)) + w[i-7] +
		(ROTR32(w[i-15],7)^ROTR32(w[i-15],18)^(w[i-15]>>3)) + w[i-16];
	a=c->h[0]; b=c->h[1]; cc=c->h[2]; d=c->h[3]; e=c->h[4]; f=c->h[5]; g=c->h[6]; h=c->h[7];
	for (i = 0; i < 64; ++i)
	{
		t1 = h + (ROTR32(e,6)^ROTR32(e,11)^ROTR32(e,25)) + ((e&f)^(~e&g)) + g_k[i] + w[i];
		t2 = (ROTR32(a,2)^ROTR32(a,13)^ROTR32(a,22)) + ((a&b)^(a&cc)^(b&cc));
		h=g; g=f; f=e; e=d+t1; d=cc; cc=b; b=a; a=t1+t2;
	}
	c->h[0]+=a; c->h[1]+=b; c->h[2]+=cc; c->h[3]+=d; c->h[4]+=e; c->h[5]+=f; c->h[6]+=g; c->h[7]+=h;
}
static void Sha256(const unsigned char* data, unsigned int len, unsigned char out[32])
{
	SHA256_CTX c; unsigned char tail[128]; unsigned int padLen; unsigned long long bits = (unsigned long long)len * 8; int i;
	c.h[0]=0x6A09E667U;c.h[1]=0xBB67AE85U;c.h[2]=0x3C6EF372U;c.h[3]=0xA54FF53AU;
	c.h[4]=0x510E527FU;c.h[5]=0x9B05688CU;c.h[6]=0x1F83D9ABU;c.h[7]=0x5BE0CD19U;
	c.used=0;c.total=0;
	while (len >= 64) { Sha256Block(&c, data); data += 64; len -= 64; }
	padLen = (len < 56) ? (56 - len) : (120 - len);
	memset(tail, 0, sizeof(tail));
	memcpy(tail, data, len);
	tail[len] = 0x80;
	for (i = 0; i < 8; ++i)
		tail[padLen + len + i] = (unsigned char)(bits >> (56 - i * 8));
	Sha256Block(&c, tail);
	if (padLen + len + 8 > 64)
		Sha256Block(&c, tail + 64);
	for (i = 0; i < 8; ++i)
	{
		out[i*4]=(unsigned char)(c.h[i]>>24);out[i*4+1]=(unsigned char)(c.h[i]>>16);
		out[i*4+2]=(unsigned char)(c.h[i]>>8);out[i*4+3]=(unsigned char)c.h[i];
	}
}

/* HD_FSWHOLEAREA: HD_WHOLEAREAFS/MD1CS089_APP.cpp, SafeAccess_Type2() */
static unsigned int CalcSha256Key(unsigned int seed)
{
	unsigned char msg[4];
	unsigned char digest[32];
	unsigned int x = seed ^ 0x2D4F68C9U;

	msg[0] = (unsigned char)(x >> 24);
	msg[1] = (unsigned char)(x >> 16);
	msg[2] = (unsigned char)(x >> 8);
	msg[3] = (unsigned char)x;
	Sha256(msg, 4, digest);
	return ((unsigned int)(digest[9] ^ 0x44) << 24) | ((unsigned int)(digest[10] ^ 0x49) << 16) |
		((unsigned int)(digest[11] ^ 0x4D) << 8) | (unsigned int)(digest[12] ^ 0x53);
}

struct SEED_KEY_PAIR { unsigned int seed; unsigned int key; };

static const SEED_KEY_PAIR g_pairs[8] =
{
	{ 0xA3D19569U, 0x72F41DD8U },
	{ 0x6843E2AFU, 0xE001C13CU },
	{ 0x9188FF6DU, 0xE0B77DB7U },
	{ 0x0F50E67DU, 0xAF60DE1EU },
	{ 0x9276E876U, 0x1470BE6CU },
	{ 0x1C7EEEB0U, 0xB5EA17D4U },
	{ 0xEF102BA8U, 0x87B442AAU },
	{ 0x1A5A4904U, 0xF511719BU }
};

int main(void)
{
	int i, maskHits = 0, type2Hits = 0, alg162Hits = 0;

	printf("%-10s %-10s %-10s %-10s %-10s\n", "SEED", "KEY", "MASK", "SHA256", "ALG162");
	for (i = 0; i < 8; ++i)
	{
		unsigned char seed[4];
		unsigned int maskKey, type2Key, alg162Key;

		seed[0] = (unsigned char)(g_pairs[i].seed >> 24);
		seed[1] = (unsigned char)(g_pairs[i].seed >> 16);
		seed[2] = (unsigned char)(g_pairs[i].seed >> 8);
		seed[3] = (unsigned char)g_pairs[i].seed;
		maskKey = CalcMaskKey(g_pairs[i].seed);
		type2Key = CalcSha256Key(g_pairs[i].seed);
		alg162Key = Alg162(seed);
		maskHits += (maskKey == g_pairs[i].key);
		type2Hits += (type2Key == g_pairs[i].key);
		alg162Hits += (alg162Key == g_pairs[i].key);
		printf("%08X   %08X   %08X   %08X   %08X\n", g_pairs[i].seed, g_pairs[i].key,
			maskKey, type2Key, alg162Key);
	}
	printf("\nMatches: MASK %d/8, SHA256(Type2) %d/8, ALG162 %d/8\n", maskHits, type2Hits, alg162Hits);
	return 0;
}
