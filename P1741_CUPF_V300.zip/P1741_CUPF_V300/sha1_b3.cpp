//#include "pch.h"
#include <cstring>
#include "sha1_b3.h"
#include <cstdint>
#include "VMProtectSDK.h"
//#define SHA1HANDSOFF

namespace nsp_zznissan_sha1_b3
{
	/* Hash a single 512-bit block. This is the core of the algorithm. */
	void SHA1B3_Transform(unsigned long state[5], unsigned char buffer[64])
	{
		unsigned int xa, xb, xc, xd, xe, t;

		typedef union {
			unsigned char c[64];
			uint32_t l[16];
		} CHAR64LONG16;
		CHAR64LONG16* block;

#ifdef SHA1HANDSOFF
		unsigned char workspace[64];

		block = (CHAR64LONG16*)workspace;
		memcpy(block, buffer, 64);
#else
		block = (CHAR64LONG16*)buffer;
#endif

		xa = state[0];
		xb = state[1];
		xc = state[2];
		xd = state[3];
		xe = state[4];

		T0(xa, xb, xc, xd, xe, 0, 11);
		T0(xe, xa, xb, xc, xd, 1, 14);
		T0(xd, xe, xa, xb, xc, 2, 15);
		T0(xc, xd, xe, xa, xb, 3, 12);
		T0(xb, xc, xd, xe, xa, 4, 5);
		T0(xa, xb, xc, xd, xe, 5, 8);
		T0(xe, xa, xb, xc, xd, 6, 7);
		T0(xd, xe, xa, xb, xc, 7, 9);
		T0(xc, xd, xe, xa, xb, 8, 11);
		T0(xb, xc, xd, xe, xa, 9, 13);
		T0(xa, xb, xc, xd, xe, 10, 14);
		T0(xe, xa, xb, xc, xd, 11, 15);
		T0(xd, xe, xa, xb, xc, 12, 6);;
		T0(xc, xd, xe, xa, xb, 13, 7);
		T0(xb, xc, xd, xe, xa, 14, 9);
		T0(xa, xb, xc, xd, xe, 15, 8);


		TR0(xe, xa, xb, xc, xd, 7, 7);
		TR0(xd, xe, xa, xb, xc, 4, 6);
		TR0(xc, xd, xe, xa, xb, 13, 8);
		TR0(xb, xc, xd, xe, xa, 1, 13);
		TR0(xa, xb, xc, xd, xe, 10, 11);
		TR0(xe, xa, xb, xc, xd, 6, 9);
		TR0(xd, xe, xa, xb, xc, 15, 7);
		TR0(xc, xd, xe, xa, xb, 3, 15);
		TR0(xb, xc, xd, xe, xa, 12, 7);
		TR0(xa, xb, xc, xd, xe, 0, 12);
		TR0(xe, xa, xb, xc, xd, 9, 15);
		TR0(xd, xe, xa, xb, xc, 5, 9);
		TR0(xc, xd, xe, xa, xb, 2, 11);
		TR0(xb, xc, xd, xe, xa, 14, 7);
		TR0(xa, xb, xc, xd, xe, 11, 13);
		TR0(xe, xa, xb, xc, xd, 8, 12);

		TR1(xd, xe, xa, xb, xc, 3, 11);
		TR1(xc, xd, xe, xa, xb, 10, 13);
		TR1(xb, xc, xd, xe, xa, 14, 6);
		TR1(xa, xb, xc, xd, xe, 4, 7);
		TR1(xe, xa, xb, xc, xd, 9, 14);
		TR1(xd, xe, xa, xb, xc, 15, 9);
		TR1(xc, xd, xe, xa, xb, 8, 13);
		TR1(xb, xc, xd, xe, xa, 1, 15);
		TR1(xa, xb, xc, xd, xe, 2, 14);
		TR1(xe, xa, xb, xc, xd, 7, 8);
		TR1(xd, xe, xa, xb, xc, 0, 13);
		TR1(xc, xd, xe, xa, xb, 6, 6);
		TR1(xb, xc, xd, xe, xa, 13, 5);
		TR1(xa, xb, xc, xd, xe, 11, 12);
		TR1(xe, xa, xb, xc, xd, 5, 7);
		TR1(xd, xe, xa, xb, xc, 12, 5);

		TR2(xc, xd, xe, xa, xb, 1, 11);
		TR2(xb, xc, xd, xe, xa, 9, 12);
		TR2(xa, xb, xc, xd, xe, 11, 14);
		TR2(xe, xa, xb, xc, xd, 10, 15);
		TR2(xd, xe, xa, xb, xc, 0, 14);
		TR2(xc, xd, xe, xa, xb, 8, 15);
		TR2(xb, xc, xd, xe, xa, 12, 9);
		TR2(xa, xb, xc, xd, xe, 4, 8);
		TR2(xe, xa, xb, xc, xd, 13, 9);
		TR2(xd, xe, xa, xb, xc, 3, 14);
		TR2(xc, xd, xe, xa, xb, 7, 5);
		TR2(xb, xc, xd, xe, xa, 15, 6);
		TR2(xa, xb, xc, xd, xe, 14, 8);
		TR2(xe, xa, xb, xc, xd, 5, 6);
		TR2(xd, xe, xa, xb, xc, 6, 5);
		TR2(xc, xd, xe, xa, xb, 2, 12);

		TR3(xb, xc, xd, xe, xa, 4, 9);
		TR3(xa, xb, xc, xd, xe, 0, 15);
		TR3(xe, xa, xb, xc, xd, 5, 5);
		TR3(xd, xe, xa, xb, xc, 9, 11);
		TR3(xc, xd, xe, xa, xb, 7, 6);
		TR3(xb, xc, xd, xe, xa, 12, 8);
		TR3(xa, xb, xc, xd, xe, 2, 13);
		TR3(xe, xa, xb, xc, xd, 10, 12);
		TR3(xd, xe, xa, xb, xc, 14, 5);
		TR3(xc, xd, xe, xa, xb, 1, 12);
		TR3(xb, xc, xd, xe, xa, 3, 13);
		TR3(xa, xb, xc, xd, xe, 8, 14);
		TR3(xe, xa, xb, xc, xd, 11, 11);
		TR3(xd, xe, xa, xb, xc, 6, 8);
		TR3(xc, xd, xe, xa, xb, 15, 5);
		TR3(xb, xc, xd, xe, xa, 13, 6);


		unsigned int na, nb, nc, nd, ne;
		na = state[0];
		nb = state[1];
		nc = state[2];
		nd = state[3];
		ne = state[4];

		TR4(na, nb, nc, nd, ne, 5, 8);
		TR4(ne, na, nb, nc, nd, 14, 9);
		TR4(nd, ne, na, nb, nc, 7, 9);
		TR4(nc, nd, ne, na, nb, 0, 11);
		TR4(nb, nc, nd, ne, na, 9, 13);
		TR4(na, nb, nc, nd, ne, 2, 15);
		TR4(ne, na, nb, nc, nd, 11, 15);
		TR4(nd, ne, na, nb, nc, 4, 5);
		TR4(nc, nd, ne, na, nb, 13, 7);
		TR4(nb, nc, nd, ne, na, 6, 7);
		TR4(na, nb, nc, nd, ne, 15, 8);
		TR4(ne, na, nb, nc, nd, 8, 11);
		TR4(nd, ne, na, nb, nc, 1, 14);
		TR4(nc, nd, ne, na, nb, 10, 14);
		TR4(nb, nc, nd, ne, na, 3, 12);
		TR4(na, nb, nc, nd, ne, 12, 6);

		TR5(ne, na, nb, nc, nd, 6, 9);
		TR5(nd, ne, na, nb, nc, 11, 13);
		TR5(nc, nd, ne, na, nb, 3, 15);
		TR5(nb, nc, nd, ne, na, 7, 7);
		TR5(na, nb, nc, nd, ne, 0, 12);
		TR5(ne, na, nb, nc, nd, 13, 8);
		TR5(nd, ne, na, nb, nc, 5, 9);
		TR5(nc, nd, ne, na, nb, 10, 11);
		TR5(nb, nc, nd, ne, na, 14, 7);
		TR5(na, nb, nc, nd, ne, 15, 7);
		TR5(ne, na, nb, nc, nd, 8, 12);
		TR5(nd, ne, na, nb, nc, 12, 7);
		TR5(nc, nd, ne, na, nb, 4, 6);
		TR5(nb, nc, nd, ne, na, 9, 15);
		TR5(na, nb, nc, nd, ne, 1, 13);
		TR5(ne, na, nb, nc, nd, 2, 11);

		TR6(nd, ne, na, nb, nc, 15, 9);
		TR6(nc, nd, ne, na, nb, 5, 7);
		TR6(nb, nc, nd, ne, na, 1, 15);
		TR6(na, nb, nc, nd, ne, 3, 11);
		TR6(ne, na, nb, nc, nd, 7, 8);
		TR6(nd, ne, na, nb, nc, 14, 6);
		TR6(nc, nd, ne, na, nb, 6, 6);
		TR6(nb, nc, nd, ne, na, 9, 14);
		TR6(na, nb, nc, nd, ne, 11, 12);
		TR6(ne, na, nb, nc, nd, 8, 13);
		TR6(nd, ne, na, nb, nc, 12, 5);
		TR6(nc, nd, ne, na, nb, 2, 14);
		TR6(nb, nc, nd, ne, na, 10, 13);
		TR6(na, nb, nc, nd, ne, 0, 13);
		TR6(ne, na, nb, nc, nd, 4, 7);
		TR6(nd, ne, na, nb, nc, 13, 5);

		TR7(nc, nd, ne, na, nb, 8, 15);
		TR7(nb, nc, nd, ne, na, 6, 5);
		TR7(na, nb, nc, nd, ne, 4, 8);
		TR7(ne, na, nb, nc, nd, 1, 11);
		TR7(nd, ne, na, nb, nc, 3, 14);
		TR7(nc, nd, ne, na, nb, 11, 14);
		TR7(nb, nc, nd, ne, na, 15, 6);
		TR7(na, nb, nc, nd, ne, 0, 14);
		TR7(ne, na, nb, nc, nd, 5, 6);
		TR7(nd, ne, na, nb, nc, 12, 9);
		TR7(nc, nd, ne, na, nb, 2, 12);
		TR7(nb, nc, nd, ne, na, 13, 9);
		TR7(na, nb, nc, nd, ne, 9, 12);
		TR7(ne, na, nb, nc, nd, 7, 5);
		TR7(nd, ne, na, nb, nc, 10, 15);
		TR7(nc, nd, ne, na, nb, 14, 8);

		T0(nb, nc, nd, ne, na, 12, 8);
		T0(na, nb, nc, nd, ne, 15, 5);
		T0(ne, na, nb, nc, nd, 10, 12);
		T0(nd, ne, na, nb, nc, 4, 9);
		T0(nc, nd, ne, na, nb, 1, 12);
		T0(nb, nc, nd, ne, na, 5, 5);
		T0(na, nb, nc, nd, ne, 8, 14);
		T0(ne, na, nb, nc, nd, 7, 6);
		T0(nd, ne, na, nb, nc, 6, 8);
		T0(nc, nd, ne, na, nb, 2, 13);
		T0(nb, nc, nd, ne, na, 13, 6);
		T0(na, nb, nc, nd, ne, 14, 5);
		T0(ne, na, nb, nc, nd, 0, 15);
		T0(nd, ne, na, nb, nc, 3, 13);
		T0(nc, nd, ne, na, nb, 9, 11);
		T0(nb, nc, nd, ne, na, 11, 11);

		uint32_t s0 = nd + xc + state[1];
		state[1] = ne + xd + state[2];
		state[2] = state[4] + xe + state[3];
		state[3] = nb + xa + state[4];
		state[4] = nc + xb + state[0];
		state[0] = s0;
	}
	/* SHA1Init - Initialize new context */

	void SHA1B3_Init(SHA1B3_CTX* context)
	{
#if (defined WIN32 && defined NDEBUG)
		VMProtectBegin("nsp_zznissan_sha1_b3::SHA1B3_Init");
#endif
		/* SHA1 initialization constants */
		context->state[0] = 0x67452301;
		context->state[1] = 0xEFCDAB89;
		context->state[2] = 0x98BADCFE;
		context->state[3] = 0x10325476;
		context->state[4] = 0xC3D2E1F0;
		context->count[0] = context->count[1] = 0;

#if (defined WIN32 && defined NDEBUG)
		VMProtectEnd();
#endif
	}


	/* Run your data through this. */

	void SHA1B3_Update(SHA1B3_CTX* context, unsigned char* data, unsigned int len)
	{
#if (defined WIN32 && defined NDEBUG)
		VMProtectBegin("nsp_zznissan_sha1_b3::SHA1B3_Update");
#endif
		unsigned int i, j;

		j = (context->count[0] >> 3) & 63;
		if ((context->count[0] += len << 3) < (len << 3))
			context->count[1]++;
		context->count[1] += (len >> 29);
		if ((j + len) > 63) {
			memcpy(&context->buffer[j], data, (i = 64 - j));
			SHA1B3_Transform(context->state, context->buffer);
			if ((127 - j) < len)
				return;
			j = 0;
		}
		else
			i = 0;
		memcpy(&context->buffer[j], &data[i], len - i);

#if (defined WIN32 && defined NDEBUG)
		VMProtectEnd();
#endif
	}

	void SHA1B3_Final(unsigned char digest[20], SHA1B3_CTX* context)
	{
		unsigned long i, j;
		unsigned char finalcount[8];
		unsigned char x80[200] = { 0 };
		for (i = 0; i < 8; i++) {
			finalcount[7 - i] = (unsigned char)((context->count[(i >= 4 ? 0 : 1)]
				>> ((3 - (i & 3)) * 8)) & 255);  /* Endian independent */
		}
		x80[0] = '\x80';
		int len = (context->count[0] >> 3) & 0x3F;
		int count = 120;
		if (len < 56)
			count = 56;
		SHA1B3_Update(context, x80, count - len);
		SHA1B3_Update(context, finalcount, 8);  /* Should cause a SHA1Transform() */
		memcpy(digest, context->state, 20);
		/* Wipe variables */
		i = j = 0;
		memset(context->buffer, 0, 64);
		memset(context->state, 0, 20);
		memset(context->count, 0, 8);
		memset(&finalcount, 0, 8);
	}
}



