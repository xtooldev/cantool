// Minimal VMProtect SDK stub for the standalone verification tools.
// The real project compiles sha1_b3.cpp with VMProtect; here the calls are
// no-ops so the verifier builds without the VMProtectSDK lib.
#pragma once

#define VMProtectBegin(x)
#define VMProtectEnd()
