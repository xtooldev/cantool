# -*- coding: utf-8 -*-
"""
潍柴智多星 XML 加解密工具 (WeiChai DiagSmart XML Crypt)

算法（复刻 WeiChaiTool / DiagEncrypt/DiagXMLEncrypt.cs）:
  key   = MD5( 文件名去扩展名后转大写 )[:8] -> 小写hex(16字符) -> UTF-16LE 编码 = 32字节 AES-256
  IV    = 密文 base64 解码后的前 16 字节
  算法  = AES-256-CBC
  填充  = ISO10126 (末字节=填充长度, 前面随机; .NET EncryptedXml 的默认行为)

用法:
  weichai_xml_crypt.exe <文件或目录> [...]            # 自动识别：密文解密 / 明文加密
  weichai_xml_crypt.exe -d Adapter_Body_CBCU3.xml     # 强制解密
  weichai_xml_crypt.exe -e -n Adapter_Body_CBCU3 plain.xml   # 加密，-n 指定部署时的文件名
  weichai_xml_crypt.exe -r -o out D:\\some\\dir        # 递归处理目录
"""

import argparse
import base64
import hashlib
import os
import random
import re
import sys
from pathlib import Path

from Crypto.Cipher import AES

__version__ = '1.0.0'


def _init_console():
    """让中文输出在 Windows 控制台（含打包后的 exe）正常显示。"""
    if os.name != 'nt':
        return
    try:
        os.system('chcp 65001 > nul')   # 切 UTF-8 代码页
    except Exception:
        pass
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

CIPHER_RE = re.compile(rb'<CipherValue>(.*?)</CipherValue>', re.S)
ENCRYPTED_MARK = b'<EncryptedData'

XMLENC_NS = 'http://www.w3.org/2001/04/xmlenc#'
TEMPLATE = (
    '<?xml version="1.0" encoding="utf-8"?>\r\n'
    '<EncryptedData Type="{ns}Element" xmlns="{ns}">'
    '<EncryptionMethod Algorithm="{ns}aes256-cbc" />'
    '<CipherData><CipherValue>{b64}</CipherValue></CipherData>'
    '</EncryptedData>'
).format


# --------------------------------------------------------------------------- #
# 核心算法
# --------------------------------------------------------------------------- #
def derive_key(name: str) -> bytes:
    """由文件名（去扩展名、转大写）派生 32 字节 AES-256 密钥。"""
    stem = Path(name).stem.upper()
    try:
        raw = stem.encode('gbk')          # 对应 C# Encoding.Default（中文系统=GBK）
    except UnicodeEncodeError:
        raw = stem.encode('utf-8')
    digest = hashlib.md5(raw).digest()
    hex16 = ''.join('%02x' % b for b in digest[:8])
    return hex16.encode('utf-16-le')


def is_encrypted(data: bytes) -> bool:
    return ENCRYPTED_MARK in data[:512]


def _strip_iso10126(dec: bytes) -> bytes:
    """ISO10126 去填充：末字节是填充长度，前面是随机字节。"""
    if not dec:
        raise ValueError('解密结果为空')
    pad = dec[-1]
    if not 1 <= pad <= 16:
        raise ValueError('ISO10126 填充字节非法 (%d)：密钥或文件名不匹配' % pad)
    return dec[:-pad]


def decrypt_bytes(data: bytes, name: str) -> bytes:
    m = CIPHER_RE.search(data)
    if not m:
        raise ValueError('未找到 <CipherValue> 节点')
    b64 = b''.join(m.group(1).split())
    try:
        ct = base64.b64decode(b64, validate=True)
    except Exception as e:
        raise ValueError('CipherValue base64 解码失败: %s' % e)
    if len(ct) <= 16 or len(ct) % 16:
        raise ValueError('密文长度异常 (%d 字节)' % len(ct))

    key = derive_key(name)
    dec = AES.new(key, AES.MODE_CBC, ct[:16]).decrypt(ct[16:])
    return _strip_iso10126(dec)


def encrypt_bytes(data: bytes, name: str) -> bytes:
    """把明文 XML 加密成智多星 EncryptedData 格式。name 决定密钥（应=部署后的文件名）。"""
    key = derive_key(name)
    iv = os.urandom(16)
    # ISO10126: 随机填充，末字节写填充长度
    pad_len = 16 - (len(data) % 16)
    filler = os.urandom(pad_len - 1)
    padded = data + filler + bytes([pad_len])
    ct = AES.new(key, AES.MODE_CBC, iv).encrypt(padded)
    b64 = base64.b64encode(iv + ct).decode('ascii')
    body = TEMPLATE(ns=XMLENC_NS, b64=b64)
    return body.encode('utf-8')


# --------------------------------------------------------------------------- #
# 文件级处理
# --------------------------------------------------------------------------- #
class Result:
    def __init__(self, src, dst, action, ok, msg=''):
        self.src, self.dst, self.action, self.ok, self.msg = src, dst, action, ok, msg


def process_file(src: Path, out_dir, mode: str, key_name, suffix_map, quiet=False) -> Result:
    try:
        data = src.read_bytes()
    except OSError as e:
        return Result(src, None, '-', False, '读取失败: %s' % e)

    encrypted = is_encrypted(data)
    if mode == 'auto':
        action = 'decrypt' if encrypted else 'encrypt'
    elif mode == 'decrypt':
        action = 'decrypt'
        if not encrypted:
            return Result(src, None, action, False, '不是加密文件（无 <EncryptedData>）')
    else:  # encrypt
        action = 'encrypt'
        if encrypted:
            return Result(src, None, action, False, '已是加密文件，无法再加密')

    try:
        if action == 'decrypt':
            plain = decrypt_bytes(data, src.name)
            out_name = src.stem + suffix_map['decrypt']
        else:
            # 密钥由「加密后文件的文件名」决定。加密产物要改名为 name，才能按原密钥回解。
            if key_name:
                name = Path(key_name).stem
                out = encrypt_bytes(data, name)
                out_name = name
            else:
                name = src.stem
                out = encrypt_bytes(data, name)
                out_name = name + suffix_map['encrypt']
    except Exception as e:
        return Result(src, None, action, False, str(e))

    if out_dir is None:
        dst = src.with_name(out_name)
    else:
        dst = Path(out_dir) / out_name
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
        if action == 'decrypt':
            dst.write_bytes(plain)
        else:
            dst.write_bytes(out)
    except OSError as e:
        return Result(src, None, action, False, '写入失败: %s' % e)

    size = len(plain) if action == 'decrypt' else len(out)
    return Result(src, dst, action, True, '%d 字节' % size)


def collect_inputs(paths, recursive: bool):
    """返回 [(文件, 基准目录)]；基准目录用于在 -o 时还原相对层级，避免同名文件互相覆盖。"""
    files, errors = [], []
    for p in paths:
        p = Path(p)
        if p.is_dir():
            it = p.rglob('*') if recursive else p.glob('*')
            files.extend((f, p) for f in sorted(it) if f.is_file())
        elif p.is_file():
            files.append((p, p.parent))
        else:
            errors.append('路径不存在: %s' % p)
    return files, errors


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def build_parser():
    ap = argparse.ArgumentParser(
        prog='weichai_xml_crypt',
        description='潍柴智多星 XML 加解密工具 (AES-256-CBC, 密钥由文件名派生)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument('paths', nargs='*', help='待处理的文件或目录（可直接拖拽到 exe 上）')
    g = ap.add_mutually_exclusive_group()
    g.add_argument('-d', '--decrypt', action='store_true', help='强制解密')
    g.add_argument('-e', '--encrypt', action='store_true', help='强制加密')
    ap.add_argument('-n', '--name', help='加密时使用的文件名（决定密钥），默认取输入文件主名')
    ap.add_argument('-o', '--output', help='输出目录（默认：解密输出到源目录，加密输出到 encrypted\\ 子目录）')
    ap.add_argument('-r', '--recursive', action='store_true', help='递归处理目录')
    ap.add_argument('--suffix', help='输出文件名后缀，默认 解密=.decrypted / 加密=.encrypted')
    ap.add_argument('-q', '--quiet', action='store_true', help='只输出汇总')
    ap.add_argument('--show-key', action='store_true', help='显示每个文件的派生密钥（调试用）')
    ap.add_argument('-V', '--version', action='version', version='weichai_xml_crypt %s' % __version__)
    return ap


def main(argv=None):
    ap = build_parser()
    args = ap.parse_args(argv)

    if not args.paths:
        ap.print_help()
        return 2

    mode = 'decrypt' if args.decrypt else 'encrypt' if args.encrypt else 'auto'

    d_suf = args.suffix if args.suffix is not None else '.decrypted'
    e_suf = args.suffix if args.suffix is not None else '.encrypted'
    suffix_map = {'decrypt': d_suf + '.xml' if not d_suf.endswith('.xml') else d_suf,
                  'encrypt': e_suf + '.xml' if not e_suf.endswith('.xml') else e_suf}

    files, errors = collect_inputs(args.paths, args.recursive)
    for e in errors:
        print('[错误]', e, file=sys.stderr)

    if not files:
        print('没有找到可处理的文件。', file=sys.stderr)
        return 1

    out_root = args.output
    results = []
    for f, base in files:
        if out_root is None:
            out_dir = f.parent / 'encrypted' if mode == 'encrypt' else None
        else:
            # 还原相对层级，避免批量时同名文件在输出目录里互相覆盖
            try:
                rel = f.parent.relative_to(base)
            except ValueError:
                rel = Path('.')
            out_dir = Path(out_root) / rel
        r = process_file(f, out_dir, mode, args.name, suffix_map, args.quiet)
        results.append(r)
        if not args.quiet:
            tag = 'OK ' if r.ok else 'ERR'
            extra = ''
            if r.ok and args.show_key:
                # 密钥永远由「输入文件的文件名」决定（加密时可用 -n 覆盖）
                key_src = (args.name or f.stem) if r.action == 'encrypt' else f.name
                extra = '   key=%s' % derive_key(key_src).hex()
            print('[%s] %-7s %s -> %s  %s%s' % (
                tag, r.action, f.name, r.dst.name if r.dst else '-', r.msg, extra))

    ok = [r for r in results if r.ok]
    bad = [r for r in results if not r.ok]
    print()
    print('=' * 60)
    print('总计 %d 个文件：成功 %d，失败 %d' % (len(results), len(ok), len(bad)))
    if ok:
        by = {}
        for r in ok:
            by[r.action] = by.get(r.action, 0) + 1
        for a, n in sorted(by.items()):
            print('  %s: %d' % ('解密' if a == 'decrypt' else '加密', n))
    for r in bad:
        print('  失败: %s  (%s)' % (r.src, r.msg))
    return 0 if not bad else 1


if __name__ == '__main__':
    _init_console()
    try:
        code = main()
    except KeyboardInterrupt:
        code = 130
    # 双击运行时（无参数）暂停，避免窗口一闪而过
    if getattr(sys, 'frozen', False) and len(sys.argv) == 1:
        try:
            input('\n按回车键退出...')
        except EOFError:
            pass
    sys.exit(code)
