# -*- coding: utf-8 -*-
"""
潍柴智多星 XML 加解密工具 — 统一入口

  * 双击运行（无参数）        → 打开图形界面
  * 带参数运行（拖拽/命令行）  → 命令行模式，用法同 weichai_xml_crypt.exe

打包（单个 exe，同时含 GUI 与 CLI）：
  python -m PyInstaller --onefile --console --name weichai_xml_crypt \
      --icon weichai_xml_crypt.ico weichai_xml_crypt_suite.py
"""

import ctypes
import sys


def _hide_console():
    """GUI 模式下隐藏控制台窗口，避免双击时留一个黑框。"""
    if sys.platform != 'win32':
        return
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)   # SW_HIDE = 0
    except Exception:
        pass


def _run_gui():
    _hide_console()
    import weichai_xml_crypt_gui as gui
    gui.main()


def _run_cli(argv):
    import weichai_xml_crypt as core
    core._init_console()
    return core.main(argv)


def main():
    argv = sys.argv[1:]
    # 无参数 → 图形界面（双击场景）
    if not argv:
        _run_gui()
        return 0
    # 有参数 → 命令行（拖拽文件到 exe 也走这里）
    return _run_cli(argv)


if __name__ == '__main__':
    try:
        code = main()
    except KeyboardInterrupt:
        code = 130
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except Exception:
        import traceback
        traceback.print_exc()
        code = 1
    sys.exit(code)
