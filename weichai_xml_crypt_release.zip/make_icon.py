# -*- coding: utf-8 -*-
"""生成中性图标：蓝底 + 白色挂锁 + 钥匙孔。输出多尺寸 .ico 与 .png。"""
from PIL import Image, ImageDraw
from pathlib import Path

OUT_ICO = Path(r'D:\SVN\XTOOL\tools\weichai_xml_crypt.ico')
OUT_PNG = Path(r'D:\SVN\XTOOL\tools\weichai_xml_crypt_icon.png')

S = 256
BG = (31, 78, 121, 255)      # 深蓝
BG2 = (58, 122, 180, 255)    # 稍亮的蓝（渐变）
FG = (255, 255, 255, 255)

img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# 圆角底板 + 竖向渐变
radius = 46
mask = Image.new('L', (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=radius, fill=255)
grad = Image.new('RGBA', (S, S))
gd = ImageDraw.Draw(grad)
for y in range(S):
    t = y / (S - 1)
    gd.line([(0, y), (S, y)], fill=(
        int(BG[0] + (BG2[0] - BG[0]) * t),
        int(BG[1] + (BG2[1] - BG[1]) * t),
        int(BG[2] + (BG2[2] - BG[2]) * t), 255))
img.paste(grad, (0, 0), mask)

# 锁环（U 形）：外圈画白，再用底色挖内圈
draw = ImageDraw.Draw(img)
cx = S // 2
ring_w = 26
outer_r = 66
ring_top = 52
# 用圆弧 + 直线拼 U 形
arc_box = [cx - outer_r, ring_top, cx + outer_r, ring_top + outer_r * 2]
d.arc(arc_box, start=180, end=360, fill=FG, width=ring_w)
# 两侧竖线补到锁体
d.line([cx - outer_r + ring_w // 2, ring_top + outer_r, cx - outer_r + ring_w // 2, 132], fill=FG, width=ring_w)
d.line([cx + outer_r - ring_w // 2, ring_top + outer_r, cx + outer_r - ring_w // 2, 132], fill=FG, width=ring_w)

# 锁体
body = [cx - 78, 120, cx + 78, 212]
d.rounded_rectangle(body, radius=22, fill=FG)

# 钥匙孔（底色挖出）
hole_col = (31, 78, 121, 255)
d.ellipse([cx - 15, 146, cx + 15, 176], fill=hole_col)
d.polygon([(cx - 11, 170), (cx + 11, 170), (cx + 6, 200), (cx - 6, 200)], fill=hole_col)

img.save(OUT_PNG)
img.save(OUT_ICO, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print('wrote', OUT_ICO)
print('wrote', OUT_PNG)
