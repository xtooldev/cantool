# -*- coding: utf-8 -*-
"""
潍柴智多星 XML 加解密工具 — 图形界面版

依赖同目录的 weichai_xml_crypt.py（算法实现）。
打包：python -m PyInstaller --onefile --windowed --name weichai_xml_crypt_gui \
        --icon weichai_xml_crypt.ico --add-data "weichai_xml_crypt.py;." weichai_xml_crypt_gui.py
"""

import os
import queue
import sys
import threading
import traceback
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# ---- 导入算法模块（兼容打包后的临时解包目录） ----
def _load_core():
    here = Path(__file__).resolve().parent
    meipass = getattr(sys, '_MEIPASS', None)
    for base in [here] + ([Path(meipass)] if meipass else []):
        if (base / 'weichai_xml_crypt.py').exists():
            sys.path.insert(0, str(base))
            break
    import weichai_xml_crypt as core
    return core


core = _load_core()

APP_TITLE = '潍柴智多星 XML 加解密工具'
APP_VER = 'v1.0.0'


def resource_path(name):
    base = getattr(sys, '_MEIPASS', None)
    if base:
        p = Path(base) / name
        if p.exists():
            return p
    return Path(__file__).resolve().parent / name


class App(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=10)
        self.pack(fill='both', expand=True)
        self.master.title('%s %s' % (APP_TITLE, APP_VER))
        self.master.minsize(720, 560)

        self.log_queue = queue.Queue()
        self.worker = None
        self.src_paths = []

        self._build_widgets()
        self._set_icon()
        self.after(120, self._drain_log)

    # ------------------------------------------------------------------ UI
    def _build_widgets(self):
        # --- 输入 ---
        box = ttk.LabelFrame(self, text='1. 选择文件 / 文件夹', padding=8)
        box.pack(fill='x')

        self.src_var = tk.StringVar()
        row = ttk.Frame(box)
        row.pack(fill='x')
        ttk.Entry(row, textvariable=self.src_var).pack(side='left', fill='x', expand=True)
        ttk.Button(row, text='选择文件…', command=self.pick_files, width=11).pack(side='left', padx=(6, 0))
        ttk.Button(row, text='选择文件夹…', command=self.pick_dir, width=12).pack(side='left', padx=(4, 0))
        ttk.Button(row, text='清空', command=self.clear_src, width=6).pack(side='left', padx=(4, 0))

        opt = ttk.Frame(box)
        opt.pack(fill='x', pady=(6, 0))
        self.recursive_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(opt, text='包含子文件夹', variable=self.recursive_var).pack(side='left')

        # --- 模式 ---
        box2 = ttk.LabelFrame(self, text='2. 操作模式', padding=8)
        box2.pack(fill='x', pady=(8, 0))

        self.mode_var = tk.StringVar(value='auto')
        for val, text in (('auto', '自动识别（密文解密 / 明文加密）'),
                          ('decrypt', '只解密'),
                          ('encrypt', '只加密')):
            ttk.Radiobutton(box2, text=text, value=val, variable=self.mode_var,
                            command=self._on_mode).pack(anchor='w')

        self.name_row = ttk.Frame(box2)
        ttk.Label(self.name_row, text='加密后文件名（决定密钥，留空则用原名+后缀）：').pack(side='left')
        self.name_var = tk.StringVar()
        ttk.Entry(self.name_row, textvariable=self.name_var, width=28).pack(side='left')

        # --- 输出 ---
        box3 = ttk.LabelFrame(self, text='3. 输出位置', padding=8)
        box3.pack(fill='x', pady=(8, 0))

        self.out_mode = tk.StringVar(value='auto')
        ttk.Radiobutton(box3, text='默认（解密写在源目录，加密写在 encrypted 子目录）',
                        value='auto', variable=self.out_mode, command=self._on_outmode).pack(anchor='w')
        r = ttk.Frame(box3)
        r.pack(fill='x')
        ttk.Radiobutton(r, text='指定输出目录：', value='custom',
                        variable=self.out_mode, command=self._on_outmode).pack(side='left')
        self.out_var = tk.StringVar()
        self.out_entry = ttk.Entry(r, textvariable=self.out_var, state='disabled')
        self.out_entry.pack(side='left', fill='x', expand=True, padx=(4, 6))
        self.out_btn = ttk.Button(r, text='浏览…', command=self.pick_out, state='disabled', width=8)
        self.out_btn.pack(side='left')

        # --- 执行 ---
        bar = ttk.Frame(self)
        bar.pack(fill='x', pady=(10, 0))
        self.run_btn = ttk.Button(bar, text='开始处理', command=self.run, width=14)
        self.run_btn.pack(side='left')
        self.progress = ttk.Progressbar(bar, mode='determinate')
        self.progress.pack(side='left', fill='x', expand=True, padx=8)
        self.status = ttk.Label(bar, text='就绪', width=22, anchor='e')
        self.status.pack(side='right')

        # --- 日志 ---
        box4 = ttk.LabelFrame(self, text='处理日志', padding=6)
        box4.pack(fill='both', expand=True, pady=(8, 0))
        self.log = tk.Text(box4, height=14, wrap='none', font=('Consolas', 9))
        vs = ttk.Scrollbar(box4, orient='vertical', command=self.log.yview)
        hs = ttk.Scrollbar(box4, orient='horizontal', command=self.log.xview)
        self.log.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        self.log.grid(row=0, column=0, sticky='nsew')
        vs.grid(row=0, column=1, sticky='ns')
        hs.grid(row=1, column=0, sticky='ew')
        box4.rowconfigure(0, weight=1)
        box4.columnconfigure(0, weight=1)
        self.log.tag_config('ok', foreground='#107C10')
        self.log.tag_config('err', foreground='#C00000')
        self.log.tag_config('sum', foreground='#1F4E79')

    def _set_icon(self):
        ico = resource_path('weichai_xml_crypt.ico')
        if ico.exists():
            try:
                self.master.iconbitmap(str(ico))
            except Exception:
                pass

    # ------------------------------------------------------------- 交互逻辑
    def _on_mode(self):
        if self.mode_var.get() == 'encrypt':
            self.name_row.pack(fill='x', pady=(6, 0))
        else:
            self.name_row.pack_forget()

    def _on_outmode(self):
        st = 'normal' if self.out_mode.get() == 'custom' else 'disabled'
        self.out_entry.configure(state=st)
        self.out_btn.configure(state=st)

    def pick_files(self):
        fs = filedialog.askopenfilenames(
            title='选择要处理的 XML',
            filetypes=[('XML 文件', '*.xml'), ('所有文件', '*.*')])
        if fs:
            self.src_paths = [Path(x) for x in fs]
            self.src_var.set('；'.join(str(x) for x in self.src_paths[:3]) +
                             ('  等 %d 个文件' % len(self.src_paths) if len(self.src_paths) > 3 else ''))

    def pick_dir(self):
        d = filedialog.askdirectory(title='选择文件夹')
        if d:
            self.src_paths = [Path(d)]
            self.src_var.set(d)

    def clear_src(self):
        self.src_paths = []
        self.src_var.set('')

    def pick_out(self):
        d = filedialog.askdirectory(title='选择输出目录')
        if d:
            self.out_var.set(d)

    # ------------------------------------------------------------------ 运行
    def run(self):
        if self.worker and self.worker.is_alive():
            return
        if not self.src_paths:
            messagebox.showwarning('提示', '请先选择要处理的文件或文件夹。')
            return
        out_dir = self.out_var.get().strip() if self.out_mode.get() == 'custom' else None
        if self.out_mode.get() == 'custom' and not out_dir:
            messagebox.showwarning('提示', '请选择输出目录，或改回默认输出。')
            return

        self.log.delete('1.0', 'end')
        self.progress.configure(value=0, maximum=100)
        self.run_btn.configure(state='disabled', text='处理中…')
        self.status.configure(text='处理中…')

        args = dict(
            paths=[str(p) for p in self.src_paths],
            mode=self.mode_var.get(),
            recursive=self.recursive_var.get(),
            out_dir=out_dir or None,
            name=self.name_var.get().strip() or None,
        )
        self.worker = threading.Thread(target=self._work, args=(args,), daemon=True)
        self.worker.start()

    def _work(self, args):
        q = self.log_queue

        def emit(text, tag=None):
            q.put((text, tag))

        try:
            files, errors = core.collect_inputs(args['paths'], args['recursive'])
            for e in errors:
                emit('[错误] ' + e, 'err')
            if not files:
                emit('没有找到可处理的文件。', 'err')
                q.put(('__done__', (0, 0, 0)))
                return

            total = len(files)
            q.put(('__total__', total))
            d_suf, e_suf = '.decrypted', '.encrypted'
            suffix_map = {'decrypt': d_suf + '.xml', 'encrypt': e_suf + '.xml'}

            ok = bad = 0
            for i, (f, base) in enumerate(files, 1):
                if args['out_dir']:
                    try:
                        rel = f.parent.relative_to(base)
                    except ValueError:
                        rel = Path('.')
                    out = Path(args['out_dir']) / rel
                elif args['mode'] == 'encrypt':
                    out = f.parent / 'encrypted'
                else:
                    out = None

                r = core.process_file(f, out, args['mode'], args['name'], suffix_map)
                if r.ok:
                    ok += 1
                    emit('[OK ] %-7s %s  ->  %s   %s' % (
                        '解密' if r.action == 'decrypt' else '加密',
                        f.name, r.dst.name if r.dst else '-', r.msg), 'ok')
                else:
                    bad += 1
                    emit('[ERR] %-7s %s   %s' % (
                        '解密' if r.action == 'decrypt' else '加密', f.name, r.msg), 'err')
                q.put(('__progress__', (i, total)))

            emit('')
            emit('=' * 56, 'sum')
            emit('共 %d 个文件：成功 %d，失败 %d' % (total, ok, bad), 'sum')
            q.put(('__done__', (total, ok, bad)))
        except Exception:
            emit('发生未预期错误：\n' + traceback.format_exc(), 'err')
            q.put(('__done__', (0, 0, 0)))

    def _drain_log(self):
        try:
            while True:
                item = self.log_queue.get_nowait()
                kind, payload = item if isinstance(item, tuple) else (None, item)
                if kind == '__progress__':
                    done, total = payload
                    self.progress.configure(value=done, maximum=total)
                    self.status.configure(text='%d / %d' % (done, total))
                elif kind == '__total__':
                    self.progress.configure(value=0, maximum=payload)
                elif kind == '__done__':
                    total, ok, bad = payload
                    self.run_btn.configure(state='normal', text='开始处理')
                    self.status.configure(text='完成：成功 %d，失败 %d' % (ok, bad))
                    if bad:
                        messagebox.showwarning('完成', '处理完成，%d 个失败，详见日志。' % bad)
                    else:
                        messagebox.showinfo('完成', '全部处理成功，共 %d 个文件。' % ok)
                else:
                    text, tag = kind, payload
                    self.log.insert('end', (text or '') + '\n', tag or '')
                    self.log.see('end')
        except queue.Empty:
            pass
        self.after(120, self._drain_log)


def main():
    root = tk.Tk()
    try:
        root.call('tk', 'scaling', 1.2)
    except Exception:
        pass
    style = ttk.Style()
    for theme in ('vista', 'winnative', 'clam'):
        if theme in style.theme_names():
            style.theme_use(theme)
            break
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
