#pragma once

namespace FOTON_AES128
{
	void  Foton_AES128(unsigned char* Seed, unsigned char* Key, unsigned char* Mask);
}

