#include <stdio.h>
#include <string.h>
#include "FotonAes128.h"

int main()
{
    // ModeAA mask (futian_security_access.cpp:6081)
    unsigned char mask[16] = {0x7A,0x0B,0x35,0xB2,0x6C,0x34,0x77,0x8B,0x57,0x9A,0x5C,0x30,0x84,0x6A,0xD0,0xF7};
    unsigned char seeds[5][16] = {
        {0xFA,0x31,0x56,0x71,0,0,0,0,0,0,0,0,0,0,0,0},
        {0x68,0x25,0x83,0x21,0,0,0,0,0,0,0,0,0,0,0,0},
        {0xFA,0x25,0x83,0x11,0,0,0,0,0,0,0,0,0,0,0,0},
        {0xFA,0x25,0x56,0x01,0,0,0,0,0,0,0,0,0,0,0,0},
        {0x2B,0x24,0x56,0x01,0,0,0,0,0,0,0,0,0,0,0,0},
    };
    const char* hexnames[5] = {
        "FA315671000000000000000000000000",
        "68258321000000000000000000000000",
        "FA258311000000000000000000000000",
        "FA255601000000000000000000000000",
        "2B245601000000000000000000000000",
    };
    for (int n = 0; n < 5; n++) {
        unsigned char key[16] = {0};
        FOTON_AES128::Foton_AES128(seeds[n], key, mask);
        printf("seed:%s  key:", hexnames[n]);
        for (int i = 0; i < 16; i++) printf("%02X", key[i]);
        printf("\n");
    }
    return 0;
}
